
function navbar(){
 
    return `<nav>
  <h2>Foods</h2>
  <ul>
    <li><a href="/Week-1/Day-4/HTML/you/food/index.html">Home</a></li>
    <li><a href="/Week-1/Day-4/HTML/you/food/latestReceipe.html">Latest Receipe</a></li>
    <li><a href="/Week-1/Day-4/HTML/you/food/receipeOfTheDay.html">Receipe Of The Day</a></li>

  </ul>
</nav>`
}

export default navbar